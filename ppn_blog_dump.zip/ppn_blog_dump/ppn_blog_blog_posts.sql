-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: ppn_blog
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blog_posts`
--

DROP TABLE IF EXISTS `blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_posts` (
  `postID` int(11) NOT NULL,
  `postTitle` varchar(255) DEFAULT NULL,
  `postContent` text,
  `postDate` datetime DEFAULT NULL,
  `authorID` int(11) DEFAULT NULL,
  PRIMARY KEY (`postID`),
  KEY `authorID_idx` (`authorID`),
  CONSTRAINT `authorID` FOREIGN KEY (`authorID`) REFERENCES `blog_authors` (`authorID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_posts`
--

LOCK TABLES `blog_posts` WRITE;
/*!40000 ALTER TABLE `blog_posts` DISABLE KEYS */;
INSERT INTO `blog_posts` VALUES (1,'Lorem ipsum dolor sit amet.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi risus ex, volutpat vitae libero at, ultrices imperdiet leo. Phasellus nec ex ut mi rhoncus consequat quis nec risus. Maecenas non fringilla felis. Integer molestie mattis est, id tincidunt erat vestibulum id. Donec rutrum congue est non congue. Proin molestie risus augue, at dapibus augue dignissim id. Quisque ut ligula laoreet, dignissim diam at, finibus velit. Donec accumsan gravida arcu, sed feugiat lectus scelerisque at. Mauris semper diam eu felis fringilla, sit amet fringilla lectus malesuada.','2017-03-25 00:00:00',1),(2,'Duis ullamcorper urna eu vehicula molestie','Nulla ornare interdum elit id tristique. Cras nec fermentum turpis, eget vulputate nisi. Duis rutrum, orci sed tincidunt feugiat, lacus mi dignissim nunc, at pretium purus eros eget tortor. Suspendisse pellentesque velit sem, at ultricies nibh gravida at. In bibendum tempor viverra. Donec at erat ac nulla fringilla sollicitudin a eu arcu. In velit turpis, rutrum id nulla vestibulum, feugiat volutpat felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur tortor justo, posuere sit amet sodales eget, ornare eu dui. Nunc mattis sapien metus, eu pharetra nunc rhoncus in. Vivamus tincidunt justo a pharetra aliquet.','2017-03-17 00:00:00',2),(3,'Mauris eu erat nec arcu sagittis iaculis','Donec at venenatis erat. Suspendisse potenti. Praesent semper sem odio, quis efficitur velit porta eu. Nulla sit amet finibus tortor. Fusce ac augue vel elit ullamcorper consequat. Etiam mollis egestas ligula eget rhoncus. Nunc vehicula viverra velit laoreet pharetra. Fusce leo quam, molestie a tristique a, eleifend in lacus. Mauris vitae auctor eros, lobortis fermentum nibh. Sed fermentum, erat vitae ornare varius, sapien tortor posuere purus, in tempus orci magna id justo. Suspendisse dignissim nibh vitae velit rhoncus gravida.','2017-02-18 00:00:00',1),(4,'Sed ultricies orci ut ante congue varius','Maecenas finibus vitae velit quis sagittis. Nulla et odio nibh. Etiam pellentesque blandit lacus at gravida. Nam eget risus blandit, pulvinar ipsum eu, ultrices ex. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam faucibus volutpat mi, id semper metus tincidunt commodo. Morbi vitae commodo eros. Aliquam efficitur elementum purus at dapibus. Mauris condimentum euismod mauris at pretium.','2017-01-15 00:00:00',2),(5,'Aliquam et velit eu odio rutrum dapibus vel in leo','Proin vitae nunc tincidunt, fringilla massa ut, lobortis augue. Mauris efficitur felis ut diam elementum lobortis. Maecenas gravida tempus nisl, non efficitur eros pharetra quis. Morbi massa justo, dignissim a fringilla eu, rutrum at metus. Pellentesque iaculis dapibus tortor, maximus dignissim velit lacinia sit amet. Sed in enim ut nisi dignissim porttitor. Praesent vitae enim et purus pulvinar bibendum sed eu mi. Vestibulum et dapibus lectus, at faucibus nunc.','2016-04-01 00:00:00',2),(6,'Nullam eu ipsum eget mauris rhoncus viverra','Suspendisse in porta orci. Quisque feugiat nibh sit amet hendrerit tincidunt. Nunc ac massa a libero commodo vehicula nec vitae velit. Cras vel sagittis purus, sed aliquam libero. Duis fringilla est eget scelerisque placerat. Curabitur vehicula tincidunt lacus sed vulputate. Phasellus aliquet tellus at purus eleifend, sit amet ullamcorper dolor posuere. Cras vulputate nec est eget tempus. Suspendisse dapibus, eros varius tincidunt ultrices, orci neque sagittis elit, interdum consectetur tortor diam quis dui. Vivamus nec nibh id ante sollicitudin sollicitudin a vel augue. Etiam semper magna id facilisis eleifend. Pellentesque feugiat placerat massa in varius. Integer tristique egestas libero, sed sagittis quam maximus a. In ac metus ex. Fusce metus ligula, vehicula id elit in, rhoncus bibendum arcu.','2016-03-31 00:00:00',1),(7,'Integer tincidunt nunc in est gravida pharetra','Integer vestibulum erat eget pharetra tincidunt. Vestibulum ut vulputate libero, vitae blandit tellus. Vestibulum eget interdum urna. Sed finibus auctor nibh, vitae auctor dolor fringilla ac. Duis condimentum eros elit, blandit accumsan mauris ornare sed. Ut auctor, turpis nec pharetra rutrum, lectus libero rutrum nisi, quis commodo augue tortor non nulla. Interdum et malesuada fames ac ante ipsum primis in faucibus. Quisque eleifend condimentum felis, non dapibus sapien interdum nec. Cras venenatis auctor pretium. Suspendisse potenti. Phasellus cursus nisi at dolor mattis condimentum. Nunc diam nunc, euismod at feugiat at, fringilla at odio.','2016-05-05 00:00:00',2);
/*!40000 ALTER TABLE `blog_posts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-30 17:41:07
